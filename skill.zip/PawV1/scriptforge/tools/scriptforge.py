#!/usr/bin/env python3
"""ScriptForge CLI - PawV1 scripting layer (niche menus, idea scaffolds, script checks).

  python3 scriptforge/tools/scriptforge.py niches
  python3 scriptforge/tools/scriptforge.py ideas 3.2
  python3 scriptforge/tools/scriptforge.py ideas "What If - Space"
  python3 scriptforge/tools/scriptforge.py check narration.txt
  python3 scriptforge/tools/scriptforge.py template

All output is plain text you can paste straight into chat. `check` is the bridge to the
PawV1 render modes: it validates the 450-600 word target and recommends the exact
studio3d / studio2d command for the script's length.
"""
import argparse, json, random, re, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = json.loads((HERE / ".." / "niches.json").read_text(encoding="utf-8"))

TITLE_PATTERNS = [
    ("listicle",        "{n} {thing} That Will {effect}"),
    ("deep-dive",       "The Hidden Science of {thing}"),
    ("truth-about",     "The Truth About {thing}"),
    ("countdown",       "{n} Signs {thing} Is {verdict}"),
    ("story",           "What Happens When {thing} Goes Too Far"),
    ("question",        "Why Does {thing} Feel Impossible to {verb}?"),
    ("mistake",         "You're Doing {thing} Wrong (And How to Fix It)"),
    ("timeline",        "{n} Days of {thing}: A Timeline"),
]
HOOK_ANGLES = [
    "Opens a loop the viewer needs closed",
    "Contradicts common advice (curiosity gap)",
    "Direct 'you' stakes - personal, urgent",
    "Shocking comparison or scale flip",
    "Mid-action story open, context later",
    "Named concept the viewer half-knows",
    "Cost of inaction made vivid",
    "Myth-bust with a specific source",
    "Countdown promise with a twist at #1",
    "Identity hook - 'people like us'",
]
FILL = {
    "n": ["3", "5", "7", "10"],
    "effect": ["Rewire Your Brain", "Change Your Life", "Save Your Focus", "Compound Daily"],
    "verdict": ["Working Against You", "Stealing Your Time", "More Common Than You Think"],
    "verb": ["Resist", "Escape", "Start", "Maintain"],
}


def _resolve(key: str):
    """Accept '3.2', '3', or a fuzzy sub-niche name."""
    subs = {}
    for nid, n in DATA["niches"].items():
        for sid, name in n["sub"].items():
            subs[sid] = (nid, sid, name, n["name"], n["style"])
        if key == nid:
            return [(nid, sid, name, n["name"], n["style"]) for sid, name in n["sub"].items()], n["name"], n["style"]
    if key in subs:
        row = subs[key]
        return [row], row[3], row[4]
    k = key.lower().strip()
    hits = [r for r in subs.values() if k in r[2].lower() or k in r[3].lower()]
    if hits:
        return hits, hits[0][3], hits[0][4]
    return [], None, None


def cmd_niches(_):
    print("ScriptForge niche menu - pick a sub-niche (e.g. '3.2') or type your own:\n")
    for nid, n in DATA["niches"].items():
        print(f"{nid}. {n['name']}")
        for sid, name in n["sub"].items():
            print(f"   {sid} {name}")
    print("\nVoice per niche:")
    for nid, n in DATA["niches"].items():
        print(f"  {n['name']}: {n['style'][:88]}...")


def cmd_ideas(args):
    rows, niche_name, _ = _resolve(args.subniche)
    if not rows:
        print(json.dumps({"error": f"unknown sub-niche {args.subniche!r}", "hint": "run `niches` first"}))
        sys.exit(1)
    rnd = random.Random(args.seed or args.subniche)
    print(f"10 idea scaffolds for [{niche_name}] - sharpen these titles (<60 chars) and hooks:\n")
    topic = rows[0][2] if len(rows) == 1 else niche_name
    order = rnd.sample(TITLE_PATTERNS, len(TITLE_PATTERNS))
    for i in range(1, 11):
        pat_name, pat = order[(i - 1) % len(order)]
        fill = {k: rnd.choice(v) for k, v in FILL.items()}
        title = pat.format(thing=topic, **fill)
        hook = HOOK_ANGLES[(i - 1) % len(HOOK_ANGLES)]
        print(f"{i:2d}. [{pat_name}] {title[:59]}\n      hook: {hook}")
    print("\nMix listicles, deep-dives, 'the truth about...', countdowns and stories.")
    print("Next: user picks one -> write the 450-600 word script (Step 3 of PROMPT.md).")


def _route(words: int) -> dict:
    sec = words / DATA["script"]["wpm"] * 60
    if sec <= 75:
        mode = "studio3d vertical short"
        cmd = "python3 SKILL/studio3d/tools/make.py --name <slug> --script s.txt --size vertical"
    elif sec <= 240:
        mode = "studio3d 720p"
        cmd = "python3 SKILL/studio3d/tools/make.py --name <slug> --script s.txt --size 720p"
    elif sec <= 420:
        mode = "studio2d stick-figure story (or shorts style)"
        cmd = "cd SKILL/studio2d && python3 tools/new_project.py <slug>   # or Mode B shorts"
    else:
        mode = "split into parts (studio3d per part)"
        cmd = "split narration.txt into 2-4 parts, render each with studio3d"
    return {"words": words, "est_seconds": round(sec, 1), "est_runtime": f"{int(sec // 60)}:{int(sec % 60):02d}",
            "recommended_mode": mode, "command": cmd}


def cmd_check(args):
    text = Path(args.script).read_text(encoding="utf-8", errors="replace")
    narration = re.sub(r"\[[^\]]*\]|\([^)]*\)|#\w+.*$", "", text, flags=re.M)
    words = len(re.findall(r"[A-Za-z0-9']+", narration))
    lo, hi = DATA["script"]["words_min"], DATA["script"]["words_max"]
    verdict = "OK (ScriptForge 450-600 target)" if lo <= words <= hi else (
        f"SHORT by {lo - words} words - expand beats" if words < lo else f"LONG by {words - hi} words - cut filler")
    print(json.dumps(_route(words) | {"verdict": verdict, "target": f"{lo}-{hi} words",
                                      "structure": [b["beat"] + " " + b["time"] for b in DATA["script"]["structure"]]}, indent=2))


def cmd_template(_):
    print("""# [NARRATION] lines below are what gets spoken; [VISUAL] lines are cues only.
## HOOK 0:00-0:15
[NARRATION] One shocking line. No greeting.
[VISUAL] close-up, hard cut on the first word
## SETUP 0:15-0:40
[NARRATION] Why this matters to you - open the curiosity loop.
[VISUAL] wide shot establishing stakes
## MAIN BODY 0:40-3:00
[NARRATION] Beat 1 ... ends on a mini-cliffhanger.
[VISUAL] data card / diagram
[NARRATION] Beat 2 ...
[VISUAL] ...
## PAYOFF 3:00-3:30
[NARRATION] The biggest reveal.
[VISUAL] hero shot, slow push-in
## OUTRO 3:30-4:00
[NARRATION] Closing line + one natural call to action.
[VISUAL] end card
# Then: 3 alt titles | thumbnail text (2-4 words) | 5 tags | word count + runtime
# Bridge: python3 SKILL/scriptforge/tools/scriptforge.py check narration.txt""")


def main():
    ap = argparse.ArgumentParser(description="ScriptForge CLI (PawV1)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("niches", help="print the niche menu")
    p = sub.add_parser("ideas", help="10 idea scaffolds for a sub-niche")
    p.add_argument("subniche", help="e.g. 3.2 or 'Space & the Universe'")
    p.add_argument("--seed", help="random seed for variety")
    p = sub.add_parser("check", help="word count, runtime, PawV1 mode router")
    p.add_argument("script", help="path to narration/script .txt")
    sub.add_parser("template", help="print the ScriptForge script skeleton")
    args = ap.parse_args()
    {"niches": cmd_niches, "ideas": cmd_ideas, "check": cmd_check, "template": cmd_template}[args.cmd](args)


if __name__ == "__main__":
    main()
