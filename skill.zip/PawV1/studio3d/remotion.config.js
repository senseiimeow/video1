// @ts-check
// PawV1 studio3d - Remotion config
// Browser: prefer PAW_CHROME env, then ~/.local/bin/chromium (PawV1 setup symlinks Playwright Chromium here)
const { Config } = require('@remotion/cli/config');
const os = require('os');
const path = require('path');

Config.setVideoImageFormat('jpeg');
Config.setJpegQuality(92);
Config.setOverwriteOutput(true);
Config.setConcurrency(parseInt(process.env.PAW_CONCURRENCY || '1', 10));
Config.setChromiumDisableWebSecurity(true);
// Browser: Remotion needs the old-headless "chrome-headless-shell".
// Order: PAW_CHROME env -> Playwright's headless shell (setup.py symlinks/uses this)
//        -> Remotion's own shell (npx remotion browser ensure)
const fs = require('fs');
const glob = (pat) => {
  const dir = path.join(os.homedir(), '.cache', 'ms-playwright');
  try {
    const hits = fs.readdirSync(dir)
      .filter((d) => d.startsWith('chromium_headless_shell'))
      .sort()
      .reverse()
      .map((d) => path.join(dir, d, 'chrome-headless-shell-linux64', 'chrome-headless-shell'));
    return hits.find((p) => fs.existsSync(p)) || null;
  } catch { return null; }
};
const chrome = process.env.PAW_CHROME
  || glob()
  || path.join(os.homedir(), '.cache', 'ms-playwright', 'chromium_headless_shell-1254',
    'chrome-headless-shell-linux64', 'chrome-headless-shell');
if (fs.existsSync(chrome)) {
  Config.setBrowserExecutable(chrome);
}
