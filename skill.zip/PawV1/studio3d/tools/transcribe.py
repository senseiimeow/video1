"""Transcribe a user's voice recording into script lines with local Whisper (faster-whisper).

  python3 tools/transcribe.py --audio rec.m4a --lang en --out lines.json
  python3 tools/transcribe.py --audio rec.m4a --lang hi --model large-v3-turbo

English defaults to small.en (fast); every other language defaults to large-v3-turbo.
Output: JSON array of spoken lines, ready for plan.py --lines-file.
"""
import argparse, json, subprocess
from pathlib import Path
import numpy as np


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--audio', required=True)
    ap.add_argument('--lang', default='en', help='en | hi | auto | ...')
    ap.add_argument('--model', default=None, help='default: small.en for en, large-v3-turbo otherwise')
    ap.add_argument('--out', default=None)
    a = ap.parse_args()
    model_name = a.model or ('large-v3-turbo' if a.lang != 'en' else 'small.en')
    raw = subprocess.run(
        ['ffmpeg', '-v', 'error', '-i', a.audio, '-ac', '1', '-ar', '16000', '-f', 'f32le', '-'],
        capture_output=True, check=True).stdout
    from faster_whisper import WhisperModel
    m = WhisperModel(model_name, device='cpu', compute_type='int8')
    kwargs = {'word_timestamps': False, 'vad_filter': True}
    if a.lang != 'auto':
        kwargs['language'] = a.lang
    segs, info = m.transcribe(np.frombuffer(raw, dtype=np.float32), **kwargs)
    lines = [s.text.strip() for s in segs if s.text.strip()]
    out = a.out or str(Path(a.audio).with_suffix('')) + '-lines.json'
    Path(out).write_text(json.dumps(lines, ensure_ascii=False, indent=1), encoding='utf-8')
    print(json.dumps({'lines': len(lines), 'lang': info.language, 'model': model_name, 'out': out}))


if __name__ == '__main__':
    main()
