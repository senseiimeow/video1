"""PawV1 make - ONE command from INPUT to finished 3D MP4.

  python3 tools/make.py --name glm-viral --script script.txt
  python3 tools/make.py --name glm-viral --text "Line one. Line two."
  python3 tools/make.py --name glm-viral --voice recording.m4a          (your own voice)
  python3 tools/make.py --name glm-viral --script s.txt --look sunset --size vertical

Pipeline: plan -> voice (Kokoro TTS or your recording) -> word timings (Whisper)
       -> music + mix (numpy) -> export data.json -> Remotion render in chunks
       -> concat -> mux audio -> loudnorm -14 LUFS -> final.mp4

Rendered chunks are CACHED: if a run is interrupted (agent timeout, sandbox kill),
just re-run the exact same command - finished chunks are reused, only the rest renders.
Use --skip-render to stop after the plan/voice/music stages (inspect data.json first),
and --resume-render to start a fresh call directly at the render step.
"""
import argparse, json, math, os, shutil, subprocess, sys, time
from pathlib import Path

STUDIO = Path(__file__).resolve().parent.parent          # .../PawV1/studio3d
PAW = STUDIO.parent                                      # .../PawV1
SHORTS = PAW / 'shorts' / 'scripts'
VENV_PY = Path(os.environ.get('FACELESS_HOME', Path.home() / '.faceless-shorts')) / 'venv' / 'bin' / 'python'
SIZES = {'720p': (1280, 720), 'vertical': (720, 1280), 'square': (1080, 1080), '1080p': (1920, 1080)}


def run(cmd, cwd=None, env=None, capture=True, timeout=560):
    e = dict(os.environ)
    if env:
        e.update(env)
    print(f'  $ {" ".join(str(c) for c in cmd[:6])}{" ..." if len(cmd) > 6 else ""}', flush=True)
    r = subprocess.run([str(c) for c in cmd], cwd=cwd, env=e,
                       capture_output=capture, text=True, timeout=timeout)
    if capture and r.stdout.strip():
        print('  ' + r.stdout.strip().replace('\n', '\n  ')[-800:], flush=True)
    if r.returncode != 0:
        sys.exit(f'command failed ({r.returncode}):\n{(r.stderr or r.stdout)[-1200:]}')
    return r


def which_ffmpeg():
    f = shutil.which('ffmpeg')
    if not f:
        sys.exit('ffmpeg not found on PATH - install it first (see SKILL.md)')
    return f


def render_chunks(a, proj, total, t0):
    rdir = proj / 'render'
    rdir.mkdir(exist_ok=True)
    chunk = max(1, int(a.chunk_sec * a.fps))
    spans = [(s, min(s + chunk - 1, total - 1)) for s in range(0, total, chunk)]
    tchunk0 = time.time()
    done = 0
    for i, (s0, s1) in enumerate(spans):
        f = rdir / f'chunk_{i:03d}.mp4'
        if f.exists() and f.stat().st_size > 10000:
            print(f'  chunk {i + 1}/{len(spans)} cached', flush=True)
            done += 1
            continue
        tc0 = time.time()
        run(['npx', 'remotion', 'render', 'Paw3D', f,
             '--props', 'public/data.json', '--frames', f'{s0}-{s1}',
             '--muted', '--crf', str(a.crf), '--log', 'error',
             '--concurrency', str(a.concurrency)],
            cwd=STUDIO, timeout=560)
        print(f'  chunk {i + 1}/{len(spans)} frames {s0}-{s1} in {time.time() - tc0:.0f}s', flush=True)
    per_frame = (time.time() - tchunk0) / total
    return rdir, spans, per_frame


def finish(a, proj, rdir, nchunks, data, total, per_frame, t0):
    lst = rdir / 'list.txt'
    lst.write_text('\n'.join(f"file '{(rdir / f'chunk_{i:03d}.mp4').resolve()}'" for i in range(nchunks)))
    video = rdir / 'video_full.mp4'
    run([which_ffmpeg(), '-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', lst, '-c', 'copy', video])
    final = proj / f'{a.name}.mp4'
    run([which_ffmpeg(), '-v', 'error', '-y', '-i', video, '-i', data / 'audio.wav',
         '-map', '0:v', '-map', '1:a', '-c:v', 'copy',
         '-af', 'loudnorm=I=-14:TP=-1.5:LRA=11', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000',
         '-movflags', '+faststart', final])
    if not a.keep_chunks:
        for i in range(nchunks):
            (rdir / f'chunk_{i:03d}.mp4').unlink(missing_ok=True)
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(final, a.out)
    fps = json.loads((STUDIO / 'public' / 'data.json').read_text()).get('fps', 30)
    print(json.dumps({'final': str(final), 'frames': total,
                      'duration_s': round(total / fps, 2),
                      'sec_per_frame': round(per_frame, 2),
                      'total_min': round((time.time() - t0) / 60, 1)}, indent=1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--name', required=True)
    ap.add_argument('--script'); ap.add_argument('--text'); ap.add_argument('--voice')
    ap.add_argument('--lang', default='en', help='for --voice transcription: en|hi|auto')
    ap.add_argument('--model', default=None, help='whisper model for --voice transcription')
    ap.add_argument('--title'); ap.add_argument('--look', default='neon',
        choices=['neon', 'sunset', 'midnight', 'candy'])
    ap.add_argument('--voice-name', default='am_michael')
    ap.add_argument('--speed', type=float, default=1.0)
    ap.add_argument('--lead', type=float, default=0.45)
    ap.add_argument('--outro', type=float, default=1.1)
    ap.add_argument('--gap', type=float, default=0.28)
    ap.add_argument('--pattern', default='orbit3d,grid3d,wave3d,burst3d')
    ap.add_argument('--size', default='720p', choices=list(SIZES))
    ap.add_argument('--fps', type=int, default=30)
    ap.add_argument('--dir'); ap.add_argument('--project-root', default=str(Path.home() / 'pawv1-projects'))
    ap.add_argument('--chunk-sec', type=float, default=9.0)
    ap.add_argument('--concurrency', type=int, default=1)
    ap.add_argument('--crf', type=int, default=17)
    ap.add_argument('--out', help='copy the final mp4 here')
    ap.add_argument('--skip-render', action='store_true', help='stop after export (inspect data.json)')
    ap.add_argument('--resume-render', action='store_true', help='steps 1-4 already done - start at the render')
    ap.add_argument('--keep-chunks', action='store_true')
    a = ap.parse_args()

    t0 = time.time()
    which_ffmpeg()
    proj = Path(a.dir) if a.dir else Path(a.project_root) / a.name
    data = proj / 'data'
    pub = STUDIO / 'public'

    if a.resume_render:
        print('[resume] steps 1-4 skipped - using existing public/data.json', flush=True)
        payload = json.loads((pub / 'data.json').read_text())
        total = int(math.ceil(payload['duration'] * payload['fps'])) + 2
    else:
        if not (a.script or a.text or a.voice):
            sys.exit('one of --script / --text / --voice is required')

        # --- 1. plan ---------------------------------------------------------
        print(f'[1/6] plan -> {proj}', flush=True)
        plan_cmd = [sys.executable, STUDIO / 'tools/plan.py', '--name', a.name, '--dir', proj,
                    '--look', a.look, '--lead', a.lead, '--outro', a.outro, '--pattern', a.pattern]
        if a.title:
            plan_cmd += ['--title', a.title]
        if a.voice and not (a.script or a.text):
            lines_file = data / 'transcript-lines.json'
            data.mkdir(parents=True, exist_ok=True)
            if not lines_file.exists():
                run([sys.executable, STUDIO / 'tools/transcribe.py', '--audio', a.voice,
                     '--lang', a.lang, '--out', lines_file], timeout=540)
            plan_cmd += ['--lines-file', lines_file, '--voice', a.voice]
        elif a.script:
            plan_cmd += ['--script', a.script]
        elif a.text:
            plan_cmd += ['--text', a.text]
        run(plan_cmd)

        # --- 2. voice --------------------------------------------------------
        print('[2/6] voice (Kokoro TTS / your recording) + word timings (Whisper)', flush=True)
        py = str(VENV_PY) if VENV_PY.exists() else sys.executable
        if a.voice and not (a.script or a.text):
            voice_in = data / ('voice_in' + Path(a.voice).suffix.lower())
            run([py, SHORTS / 'words.py', proj, '--audio', voice_in], timeout=560)
        else:
            run([py, SHORTS / 'voice.py', proj], timeout=560)
            run([py, SHORTS / 'words.py', proj], timeout=560)

        # --- 3. music + mix --------------------------------------------------
        print('[3/6] music + ducked mix', flush=True)
        r = run([py, STUDIO / 'tools/music.py', proj])
        dur = json.loads(r.stdout.strip().splitlines()[-1])['duration']

        # --- 4. export to studio3d/public ------------------------------------
        print('[4/6] export data.json + audio', flush=True)
        S = json.loads((proj / 'script.json').read_text())
        L = json.loads((data / 'lines.json').read_text())
        W = json.loads((data / 'words.json').read_text())
        w, h = SIZES[a.size]
        payload = {
            'title': S.get('title', a.name), 'look': S.get('look', 'neon'),
            'lead': S.get('lead', 0.45), 'outro': S.get('outro', 1.1),
            'lines': [{'text': ln['text'], 'scene': ln.get('scene', 'orbit3d'),
                       'keyword': ln.get('keyword'), 'gap': ln.get('gap')} for ln in S['lines']],
            'lineTimes': [{'start': ln['start'], 'end': ln['end']} for ln in L['lines']],
            'words': [{'w': x['w'], 'line': x['line'], 's': x['s'], 'e': x['e']} for x in W],
            'duration': round(dur, 3), 'fps': a.fps, 'width': w, 'height': h,
        }
        pub.mkdir(exist_ok=True)
        for old in pub.glob('*.wav'):
            old.unlink()
        (pub / 'data.json').write_text(json.dumps(payload, ensure_ascii=False, indent=1))
        shutil.copy(data / 'audio.wav', pub / 'audio.wav')
        shutil.copy(data / 'narration.wav', pub / 'narration.wav')
        total = int(math.ceil(dur * a.fps)) + 2
        print(f'  duration {dur:.2f}s = {total} frames @ {a.fps}fps', flush=True)

        if a.skip_render:
            print(json.dumps({'project': str(proj), 'data': str(pub / 'data.json'),
                              'duration': dur, 'frames': total, 'rendered': False}))
            return

    # --- 5. render in chunks (muted video only) ------------------------------
    print('[5/6] Remotion render (chunks, muted video)', flush=True)
    rdir, spans, per_frame = render_chunks(a, proj, total, t0)

    # --- 6. concat + mux + loudnorm ------------------------------------------
    print('[6/6] concat + audio mux + loudnorm -14 LUFS', flush=True)
    finish(a, proj, rdir, len(spans), data, total, per_frame, t0)


if __name__ == '__main__':
    main()
