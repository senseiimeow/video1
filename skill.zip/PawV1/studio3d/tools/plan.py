"""PawV1 plan: turn an INPUT (script text OR user's voice recording OR an idea) into a
studio3d project: script.json (lines + 3D scene per line) ready for the voice/words/music steps.

  python3 tools/plan.py --name my-video --script script.txt
  python3 tools/plan.py --name my-video --text "Line one. Line two. Line three."
  python3 tools/plan.py --name my-video --voice recording.m4a          (user speaks the script)
  python3 tools/plan.py --name my-video --script s.txt --look sunset --voice-name af_heart
                        --pattern hero3d,orbit3d,grid3d,burst3d,wave3d,outro3d

Writes <project>/script.json and prints a JSON summary. Scenes per line: first line = hero3d,
last = outro3d, middle ones cycle through --pattern (or auto: numbers/! get burst3d).
Every line = one CUT (one sentence spoken in one pass). Write numbers the way they are SAID.
"""
import argparse, json, re, sys
from pathlib import Path

SCENE_DEFAULT = ['orbit3d', 'grid3d', 'wave3d', 'burst3d']
STOP = set('''the a an and or but if of to in on for with your you we i it is are was were be been
this that these those what how why when where who its our their his her them us me my mine not no
yes so then than as at by from up down out about into over after before more most some any all
can could should would will just very really too also here there when what which do does did done
have has had get got make made go went come came say said see seen know knew think take took'''.split())


def sentences(text: str):
    """Split into spoken cuts: prefer the file's own line breaks, else sentence enders."""
    raw = [ln.strip() for ln in text.splitlines()]
    raw = [ln for ln in raw if ln and not ln.startswith('#')]
    if len(raw) >= 2:
        out = []
        for ln in raw:
            out.extend(_split_sentences(ln) if len(ln.split()) > 22 else [ln])
        return out
    return _split_sentences(' '.join(raw))


def _split_sentences(t: str):
    parts = re.split(r'(?<=[.!?…])\s+', t.strip())
    return [p.strip() for p in parts if p.strip()]


def keyword(line: str):
    toks = [re.sub(r'[^a-zA-Z0-9]', '', w) for w in line.split()]
    toks = [t for t in toks if len(t) > 3 and t.lower() not in STOP]
    if not toks:
        return None
    return max(toks, key=len).lower()


def auto_scene(i: int, n: int, line: str, pattern):
    if i == 0:
        return 'hero3d'
    if i == n - 1:
        return 'outro3d'
    if re.search(r'\b\d+\s*(%|percent|x|million|thousand|billion|k\b|seconds?)\b', line, re.I) or line.rstrip().endswith('!'):
        return 'burst3d'
    return pattern[(i - 1) % len(pattern)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--name', required=True)
    ap.add_argument('--script', help='text file with the narration (one cut per line)')
    ap.add_argument('--text', help='inline narration text')
    ap.add_argument('--lines-file', help='JSON array of lines (e.g. transcript from tools/transcribe.py)')
    ap.add_argument('--voice', help="user's own voice recording (any format ffmpeg reads)")
    ap.add_argument('--title')
    ap.add_argument('--look', default='neon', choices=['neon', 'sunset', 'midnight', 'candy'])
    ap.add_argument('--voice-name', default='am_michael')
    ap.add_argument('--speed', type=float, default=1.0)
    ap.add_argument('--lead', type=float, default=0.45)
    ap.add_argument('--outro', type=float, default=1.1)
    ap.add_argument('--gap', type=float, default=0.28)
    ap.add_argument('--pattern', default=','.join(SCENE_DEFAULT))
    ap.add_argument('--dir', help='project folder (default ~/pawv1-projects/<name>)')
    ap.add_argument('--project-root', default=str(Path.home() / 'pawv1-projects'))
    a = ap.parse_args()

    if a.script:
        text = Path(a.script).read_text(encoding='utf-8')
        lines = sentences(text)
    elif a.text:
        lines = sentences(a.text)
    elif a.lines_file:
        lines = json.loads(Path(a.lines_file).read_text(encoding='utf-8'))
        lines = [str(x).strip() for x in lines if str(x).strip()]
    elif a.voice:
        # voice-only flow: transcribe.py must have produced a lines-file; run make.py instead
        ap.error('--voice needs lines: run tools/transcribe.py first, or just use tools/make.py which does it for you')
    else:
        ap.error('one of --script / --text / --lines-file is required')

    proj = Path(a.dir) if a.dir else Path(a.project_root) / a.name
    (proj / 'data').mkdir(parents=True, exist_ok=True)

    if not lines:
        sys.exit('no lines found in the input')
    pattern = [s.strip() for s in a.pattern.split(',') if s.strip()] or SCENE_DEFAULT
    valid = set(SCENE_DEFAULT) | {'hero3d', 'outro3d'}
    for p in pattern:
        if p not in valid:
            sys.exit(f'unknown scene "{p}" - valid: {sorted(valid)}')

    script = {
        'title': a.title or (lines[0][:60] if lines else (a.name)),
        'voice': a.voice_name, 'speed': a.speed, 'lead': a.lead,
        'outro': a.outro, 'gap': a.gap, 'look': a.look,
        'pattern': pattern,
        'lines': (
            [
                {
                    'text': ln,
                    'scene': auto_scene(i, len(lines), ln, pattern),
                    'keyword': keyword(ln),
                }
                for i, ln in enumerate(lines)
            ]
            if lines
            else []
        ),
    }
    (proj / 'script.json').write_text(json.dumps(script, indent=1, ensure_ascii=False))
    if a.voice:
        src = Path(a.voice).expanduser().resolve()
        dst = proj / 'data' / ('voice_in' + src.suffix.lower())
        dst.write_bytes(src.read_bytes())
    print(json.dumps({'project': str(proj), 'lines': len(script['lines']),
                      'scenes': [ln['scene'] for ln in script['lines']]}, indent=1))


if __name__ == '__main__':
    main()
