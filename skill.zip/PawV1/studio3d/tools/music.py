"""PawV1 music + final audio mix, all numpy (no samples, no downloads).

  python3 tools/music.py <project>          -> <project>/data/music.wav (score)
                                             <project>/data/audio.wav  (voice + ducked music, 48k stereo)

Reads data/narration.wav (24 kHz mono from voice.py / words.py --audio) + data/lines.json +
script.json ("look" picks the mood). The music ducks under the voice automatically.
Duration = last line end + outro. Mood per look: neon / midnight -> minor pad + kick;
sunset -> warm major pad; candy -> bright plucks.
"""
import json, sys
from pathlib import Path
import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 48000
NR = 24000


def lp(x, f, o=2):
    b, a = signal.butter(o, min(f, SR / 2 - 200) / (SR / 2), 'low')
    return signal.lfilter(b, a, x)


def note(freq, dur, kind='saw', det=(0.0,)):
    n = int(dur * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    for d in det:
        f = freq * (2 ** (d / 1200.0))
        if kind == 'saw':
            out += signal.sawtooth(2 * np.pi * f * t)
        elif kind == 'sine':
            out += np.sin(2 * np.pi * f * t)
        elif kind == 'tri':
            out += signal.sawtooth(2 * np.pi * f * t, 0.5)
    return out / max(1, len(det))


def build_music(dur, mood):
    n = int((dur + 0.5) * SR)
    t = np.arange(n) / SR
    bpm = 112
    beat = 60.0 / bpm
    # chord roots (Hz): A2 110, F2 87.3, C3 130.8, G2 98 - i VI III VII in A minor
    if mood in ('sunset', 'candy'):
        roots = [130.8, 110.0, 87.3, 98.0]     # C Am F G - warm
    else:
        roots = [110.0, 87.3, 130.8, 98.0]     # Am F C G - minor
    music = np.zeros(n)
    bar = beat * 4
    nbars = int(np.ceil(dur / bar)) + 1
    for b in range(nbars):
        t0 = b * bar
        i0 = int(t0 * SR)
        if i0 >= n:
            break
        root = roots[b % 4]
        # pad: root + fifth + octave, detuned saws through a soft lowpass, 1 bar with fades
        chord = note(root, bar, 'saw', (-6, 0, 6)) + note(root * 1.5, bar, 'tri', (0,)) * 0.5 + note(root * 2, bar, 'saw', (-4, 4)) * 0.4
        chord = lp(chord, 900 + (80 if mood == 'candy' else 0), 2)
        env = np.ones_like(chord)
        f = int(0.25 * SR)
        env[:f] = np.linspace(0, 1, f)
        env[-f:] = np.linspace(1, 0, f)
        i1 = min(n, i0 + len(chord))
        seg = (chord * env)[: i1 - i0]
        music[i0:i1] += seg * (0.30 if mood == 'candy' else 0.24)
        # kick: soft sine thump on each beat
        for k in range(4):
            j0 = i0 + int(k * beat * SR)
            if j0 >= n:
                break
            kn = int(0.16 * SR)
            if j0 + kn >= n:
                continue
            kt = np.arange(kn) / SR
            thump = np.sin(2 * np.pi * (55 * np.exp(-kt * 9) + 42) * kt) * np.exp(-kt * 22)
            music[j0: j0 + kn] += thump * 0.5
        # shaker: tiny filtered noise on offbeats (very quiet)
        if mood == 'candy':
            for k in range(4):
                j0 = i0 + int((k + 0.5) * beat * SR)
                if j0 >= n:
                    break
                sn = int(0.05 * SR)
                if j0 + sn >= n:
                    continue
                music[j0: j0 + sn] += (np.random.default_rng(b * 4 + k).standard_normal(sn)) * np.exp(-np.arange(sn) / SR * 90) * 0.05
    music = lp(music, 7500, 2)
    return music / (np.abs(music).max() + 1e-9)


def envelope(x, win=0.06):
    hop = int(win * NR)
    m = len(x) // hop
    if m == 0:
        return np.zeros(1)
    rms = np.sqrt(np.mean(x[: m * hop].reshape(m, hop) ** 2, axis=1) + 1e-9)
    env = np.interp(np.arange(len(x)), np.arange(m) * hop + hop / 2, rms)
    env = env / (env.max() + 1e-9)
    # smooth
    b, a = signal.butter(2, 8 / (NR / 2), 'low')
    return signal.lfilter(b, a, np.clip(env, 0, 1))


def main():
    P = Path(sys.argv[1] if len(sys.argv) > 1 else '.')
    S = json.loads((P / 'script.json').read_text())
    L = json.loads((P / 'data/lines.json').read_text())
    narr_p = P / 'data/narration.wav'
    sr_n, x = wavfile.read(narr_p)
    x = x.astype(np.float64)
    if x.ndim > 1:
        x = x.mean(axis=1)
    if np.abs(x).max() > 4:
        x = x / 32768.0                      # int16 -> float
    if sr_n != NR:
        g = np.gcd(int(sr_n), NR)
        x = signal.resample_poly(x, NR // g, int(sr_n) // g)
    dur = L['lines'][-1]['end'] + S.get('outro', 1.1) + 0.45
    mood = S.get('look', 'neon')

    music = build_music(dur, mood)
    wavfile.write(P / 'data/music.wav', SR, (music * 0.9 * 32767).astype(np.int16))

    # mix: voice upsampled 24k -> 48k, music ducked under the voice envelope
    n = len(music)
    x48 = signal.resample_poly(x, SR // np.gcd(SR, NR), NR // np.gcd(SR, NR)) if SR != NR else x
    env = envelope(x)                                    # 24 kHz domain
    env48 = np.interp(np.arange(n), np.arange(len(env)) * (SR / NR), env)
    duck = 1.0 - 0.78 * np.clip(env48, 0, 1)
    voice = np.zeros(n)
    vn = min(len(x48), n)
    voice[:vn] += x48[:vn]
    mu = music * duck
    mix = voice * 1.0 + mu * 0.34
    # final tail fade
    f = int(0.35 * SR)
    if n > f:
        mix[-f:] *= np.linspace(1, 0, f)
    mix = mix / (np.abs(mix).max() + 1e-9) * 0.92
    st = np.stack([mix, mix], axis=1)
    wavfile.write(P / 'data/audio.wav', SR, (st * 32767).astype(np.int16))
    print(json.dumps({'duration': round(dur, 2), 'mood': mood, 'audio': str(P / 'data/audio.wav')}))


if __name__ == '__main__':
    main()
