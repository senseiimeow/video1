// wave3d - calm flowing wave plane with bobbing orbs. For relaxed explainer lines.
import React from 'react';
import { useCurrentFrame, useVideoConfig } from 'remotion';
import * as THREE from 'three';
import { Scene3D, TextPlane } from './Scene3D';
import { KeywordChip } from './bits';
import { pal } from '../lib/theme';
import type { Look } from '../lib/types';

const SEG = 56;

export const Wave3D: React.FC<{ look: Look; text: string; keyword?: string }> = ({ look, text, keyword }) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const p = pal(look);
  const t = frame / fps;
  const geoRef = React.useRef<THREE.PlaneGeometry>(null);
  const wave = (x: number, y: number, tt: number) =>
    Math.sin(x * 0.55 + tt * 1.5) * 0.42 + Math.cos(y * 0.5 + tt * 1.1) * 0.34;
  // mutate wave vertices (deterministic in t)
  {
    const g = geoRef.current;
    if (g) {
      const pos = g.attributes.position as THREE.BufferAttribute;
      for (let i = 0; i < pos.count; i++) {
        const x = pos.getX(i);
        const y = pos.getY(i);
        pos.setZ(i, wave(x, y, t));
      }
      pos.needsUpdate = true;
      g.computeVertexNormals();
    }
  }
  const orbs = React.useMemo(
    () =>
      Array.from({ length: 5 }, (_, i) => ({
        x: -4.4 + i * 2.2,
        ph: i * 1.3,
        s: 0.22 + (i % 3) * 0.09,
      })),
    []
  );

  return (
    <Scene3D look={look} camera={{ position: [0, 2.1, 8.6], fov: 50 }} fog={[11, 40]}>
      <mesh rotation={[-Math.PI / 2.35, 0, 0]} position={[0, -1.9, -2]}>
        <planeGeometry ref={geoRef} args={[26, 16, SEG, Math.round(SEG * 0.62)]} />
        <meshStandardMaterial
          color={p.primary} emissive={p.secondary} emissiveIntensity={0.18}
          metalness={0.35} roughness={0.4} wireframe
        />
      </mesh>
      <mesh rotation={[-Math.PI / 2.35, 0, 0]} position={[0, -1.92, -2]}>
        <planeGeometry args={[26, 16, SEG, Math.round(SEG * 0.62)]} />
        <meshStandardMaterial
          color={p.bgA} transparent opacity={0.55} metalness={0.2} roughness={0.5}
        />
      </mesh>
      {orbs.map((o, i) => (
        <mesh key={i} position={[o.x, 0.4 + Math.sin(t * 1.3 + o.ph) * 0.45, -1 + (i % 2)]}>
          <sphereGeometry args={[o.s, 28, 28]} />
          <meshStandardMaterial
            color={i % 2 ? p.secondary : p.accent}
            emissive={i % 2 ? p.secondary : p.accent}
            emissiveIntensity={0.5}
          />
        </mesh>
      ))}
      {keyword ? (
        <KeywordChip text={keyword} color={p.bgA} bg={p.accent} y={2.3} phase={0.6} />
      ) : (
        <TextPlane text={text} color={p.text} position={[0, 2.1, 0]} size={1.2} />
      )}
    </Scene3D>
  );
};
