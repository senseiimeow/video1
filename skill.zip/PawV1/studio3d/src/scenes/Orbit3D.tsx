// orbit3d - a torus-knot core with satellites riding two tilted rings.
// Camera slowly orbits; good for "here is how it works" energy.
import React from 'react';
import { useCurrentFrame, useVideoConfig } from 'remotion';
import { Scene3D, TextPlane } from './Scene3D';
import { KeywordChip, Stars } from './bits';
import { pal } from '../lib/theme';
import type { Look } from '../lib/types';

export const Orbit3D: React.FC<{ look: Look; text: string; keyword?: string }> = ({ look, text, keyword }) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const p = pal(look);
  const t = frame / fps;
  const spin = t * 0.55;
  const orbitA = Math.sin(frame / durationInFrames * Math.PI) * 1.6;

  return (
    <Scene3D
      look={look}
      camera={{ position: [Math.sin(spin * 0.4) * orbitA, 0.8 + Math.cos(spin * 0.3) * 0.4, 7.6], fov: 48 }}
    >
      <Stars color={p.particle} count={220} speed={0.014} />
      <group position={[0, -0.2, 0]}>
        <mesh>
          <torusKnotGeometry args={[1.05, 0.34, 160, 24]} />
          <meshStandardMaterial color={p.primary} metalness={0.65} roughness={0.22} />
        </mesh>
        {[0, 1].map((ring) => (
          <group key={ring} rotation={[ring ? 1.25 : -0.5, ring ? 0.4 : 0.2, ring ? -0.3 : 0.45]}>
            <mesh>
              <torusGeometry args={[2.7, 0.015, 8, 120]} />
              <meshBasicMaterial color={p.accent} transparent opacity={0.5} />
            </mesh>
            {[0, 1, 2].map((k) => {
              const a = (spin * (ring ? -1.1 : 1)) + (k * Math.PI * 2) / 3;
              return (
                <mesh key={k} position={[Math.cos(a) * 2.7, 0, Math.sin(a) * 2.7]}>
                  <sphereGeometry args={[0.17, 24, 24]} />
                  <meshStandardMaterial
                    color={p.secondary} emissive={p.secondary} emissiveIntensity={0.85}
                  />
                </mesh>
              );
            })}
          </group>
        ))}
      </group>
      {keyword ? (
        <KeywordChip text={keyword} color={p.bgA} bg={p.accent} y={2.35} phase={1.2} />
      ) : (
        <TextPlane text={text} color={p.text} position={[0, 2.25, 0]} size={1.2} />
      )}
    </Scene3D>
  );
};
