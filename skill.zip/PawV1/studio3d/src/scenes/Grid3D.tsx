// grid3d - cyber fly-through: glowing grid floor, floating cubes, camera flies forward.
// Great for "step by step" lines.
import React from 'react';
import { useCurrentFrame, useVideoConfig } from 'remotion';
import * as THREE from 'three';
import { Scene3D, TextPlane } from './Scene3D';
import { KeywordChip, mulberry } from './bits';
import { pal } from '../lib/theme';
import type { Look } from '../lib/types';

export const Grid3D: React.FC<{ look: Look; text: string; keyword?: string }> = ({ look, text, keyword }) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const p = pal(look);
  const t = frame / fps;
  const travel = (t * 3.2) % 2;           // grid scroll unit
  const camZ = 8 - ((t * 2.6) % 4);       // steady forward push, loops

  const cubes = React.useMemo(() => {
    const r = mulberry(7);
    return Array.from({ length: 14 }, () => ({
      x: (r() - 0.5) * 16,
      y: 0.6 + r() * 3.4,
      z: -4 - r() * 26,
      s: 0.35 + r() * 0.7,
      sp: 0.4 + r() * 0.8,
      ph: r() * Math.PI * 2,
    }));
  }, []);

  return (
    <Scene3D look={look} camera={{ position: [0, 1.6, camZ], fov: 55 }} fog={[6, 34]}>
      <gridHelper
        args={[60, 60, p.primary, p.secondary]}
        position={[0, 0, 0]}
        material-transparent
        material-opacity={0.35}
      />
      <gridHelper
        args={[60, 12, p.accent, p.accent]}
        position={[0, 0.02, 0]}
        material-transparent
        material-opacity={0.14}
      />
      {cubes.map((c, i) => (
        <mesh key={i} position={[c.x, c.y + Math.sin(t * c.sp + c.ph) * 0.3, c.z + travel * 0]} rotation={[t * c.sp, t * c.sp * 0.7, 0]}>
          <boxGeometry args={[c.s, c.s, c.s]} />
          <meshStandardMaterial
            color={i % 3 === 0 ? p.accent : p.primary}
            emissive={i % 3 === 0 ? p.accent : p.secondary}
            emissiveIntensity={0.35}
            transparent
            opacity={0.92}
          />
        </mesh>
      ))}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, -14]}>
        <planeGeometry args={[60, 60]} />
        <meshBasicMaterial color={p.fog} transparent opacity={0.0} />
      </mesh>
      {keyword ? (
        <KeywordChip text={keyword} color={p.bgA} bg={p.accent} y={2.6} />
      ) : (
        <TextPlane text={text} color={p.text} position={[0, 2.35, 0]} size={1.2} />
      )}
    </Scene3D>
  );
};
