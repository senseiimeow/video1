// hero3d - opening scene: big statement text, hero icosahedron with wireframe shell,
// orbiting satellites, starfield. Camera dollies in.
import React from 'react';
import { useCurrentFrame, useVideoConfig, interpolate } from 'remotion';
import * as THREE from 'three';
import { Scene3D, TextPlane } from './Scene3D';
import { Stars } from './bits';
import { pal } from '../lib/theme';
import type { Look } from '../lib/types';

export const Hero3D: React.FC<{ look: Look; text: string }> = ({ look, text }) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const p = pal(look);
  const t = frame / fps;
  const prog = Math.min(1, frame / (0.6 * fps));
  const ease = 1 - Math.pow(1 - prog, 3);
  const camZ = interpolate(frame, [0, durationInFrames], [9.5, 7.2]);
  const spin = t * 0.5;
  const bob = Math.sin(t * 1.2) * 0.18;

  return (
    <Scene3D look={look} camera={{ position: [0, 0.5, camZ], fov: 50 }}>
      <Stars color={p.particle} count={300} />
      <group position={[0, -0.9 + bob, 0]}>
        <mesh scale={ease}>
          <icosahedronGeometry args={[1.35, 1]} />
          <meshStandardMaterial color={p.primary} metalness={0.55} roughness={0.25} flatShading />
        </mesh>
        <mesh scale={ease * 1.24}>
          <icosahedronGeometry args={[1.35, 1]} />
          <meshBasicMaterial color={p.accent} wireframe transparent opacity={0.35} />
        </mesh>
        {[0, 1, 2].map((i) => {
          const a = spin * (1 + i * 0.35) + (i * Math.PI * 2) / 3;
          const rad = 2.4 + i * 0.35;
          return (
            <mesh key={i} position={[Math.cos(a) * rad, Math.sin(a * 1.3) * 0.7, Math.sin(a) * rad]}>
              <sphereGeometry args={[0.12 + i * 0.05, 24, 24]} />
              <meshStandardMaterial color={p.secondary} emissive={p.secondary} emissiveIntensity={0.6} />
            </mesh>
          );
        })}
      </group>
      <TextPlane
        text={text}
        color={p.text}
        position={[0, 1.9, 0]}
        size={1.8}
        opacity={ease}
      />
    </Scene3D>
  );
};
