// Small reusable 3D bits for PawV1 scenes. All animation derives from useCurrentFrame
// (deterministic per frame - required for Remotion rendering).
import React from 'react';
import { useCurrentFrame, useVideoConfig } from 'remotion';
import * as THREE from 'three';
import { TextPlane, makeTextTexture } from './Scene3D';

// Seeded random so every render is identical
export const mulberry = (seed: number) => {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

export const Stars: React.FC<{ color: string; count?: number; speed?: number; radius?: number }> = ({
  color, count = 260, speed = 0.02, radius = 30,
}) => {
  const frame = useCurrentFrame();
  const ref = React.useRef<THREE.Points>(null);
  const [positions, sizes] = React.useMemo(() => {
    const r = mulberry(42);
    const pos = new Float32Array(count * 3);
    const sz = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      const th = r() * Math.PI * 2;
      const ph = Math.acos(2 * r() - 1);
      const rad = radius * (0.35 + 0.65 * r());
      pos[i * 3] = rad * Math.sin(ph) * Math.cos(th);
      pos[i * 3 + 1] = rad * Math.cos(ph) * 0.6;
      pos[i * 3 + 2] = rad * Math.sin(ph) * Math.sin(th) - 8;
      sz[i] = 0.03 + r() * 0.07;
    }
    return [pos, sz];
  }, [count, radius]);
  const [grad] = React.useMemo(() => {
    const map = new Float32Array(count);
    const r = mulberry(43);
    for (let i = 0; i < count; i++) map[i] = r();
    return [map];
  }, [count]);
  if (ref.current) ref.current.rotation.y = frame * speed;
  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        <bufferAttribute attach="attributes-size" args={[grad, 1]} />
      </bufferGeometry>
      <pointsMaterial color={color} size={0.09} sizeAttenuation transparent opacity={0.85} />
    </points>
  );
};

// Floating keyword chip: rounded card with the line's keyword, gently bobbing.
export const KeywordChip: React.FC<{
  text: string; color: string; bg: string; y?: number; phase?: number;
}> = ({ text, color, bg, y = 1.9, phase = 0 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const pop = Math.min(1, frame / (0.35 * fps));
  const e = 1 - Math.pow(1 - pop, 3);
  const bob = Math.sin((frame / fps) * 1.6 + phase) * 0.12;
  const { tex, aspect } = React.useMemo(() => makeChipTexture(text, color, bg), [text, color, bg]);
  const w = 1.35 * aspect;
  return (
    <group position={[0, y + bob, 0]} scale={e}>
      <mesh>
        <planeGeometry args={[w, w / aspect]} />
        <meshBasicMaterial map={tex} transparent toneMapped={false} />
      </mesh>
    </group>
  );
};

const makeChipTexture = (text: string, color: string, bg: string) => {
  const c = document.createElement('canvas');
  c.width = 1024; c.height = 256;
  const ctx = c.getContext('2d')!;
  const r = 56;
  ctx.fillStyle = bg;
  ctx.beginPath();
  ctx.moveTo(r, 8); ctx.lineTo(1024 - r, 8); ctx.arcTo(1024 - 8, 8, 1024 - 8, 8 + r, r);
  ctx.lineTo(1024 - 8, 248 - r); ctx.arcTo(1024 - 8, 248, 1024 - r, 248, r);
  ctx.lineTo(r, 248); ctx.arcTo(8, 248, 8, 248 - r, r);
  ctx.lineTo(8, 8 + r); ctx.arcTo(8, 8, r, 8, r);
  ctx.fill();
  ctx.font = '110px "InterBlack", "Arial Black", sans-serif';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillStyle = color;
  ctx.fillText(text.slice(0, 22).toUpperCase(), 512, 132, 940);
  const tex = new THREE.CanvasTexture(c);
  tex.anisotropy = 4;
  return { tex, aspect: 4 };
};

export { TextPlane, makeTextTexture };
