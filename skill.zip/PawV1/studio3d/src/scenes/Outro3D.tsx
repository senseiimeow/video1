// outro3d - camera pulls back from a spinning torus-knot "logo", CTA text glows.
import React from 'react';
import { useCurrentFrame, useVideoConfig, interpolate } from 'remotion';
import { Scene3D, TextPlane } from './Scene3D';
import { Stars } from './bits';
import { pal } from '../lib/theme';
import type { Look } from '../lib/types';

export const Outro3D: React.FC<{ look: Look; text: string; keyword?: string }> = ({ look, text, keyword }) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const p = pal(look);
  const t = frame / fps;
  const camZ = interpolate(frame, [0, durationInFrames], [6.4, 9.6]);
  const spin = t * 0.7;
  const glow = 0.7 + Math.sin(t * 3) * 0.3;

  return (
    <Scene3D look={look} camera={{ position: [0, 0.3, camZ], fov: 50 }}>
      <Stars color={p.particle} count={280} speed={0.03} />
      <group position={[0, -0.75, 0]}>
        <mesh>
          <torusKnotGeometry args={[0.95, 0.3, 200, 28, 2, 3]} />
          <meshStandardMaterial
            color={p.primary} metalness={0.75} roughness={0.15}
            emissive={p.secondary} emissiveIntensity={glow * 0.4}
          />
        </mesh>
        <mesh scale={1.35}>
          <torusKnotGeometry args={[0.95, 0.3, 120, 20, 2, 3]} />
          <meshBasicMaterial color={p.accent} wireframe transparent opacity={0.22} />
        </mesh>
      </group>
      <TextPlane
        text={keyword || text}
        color={p.text}
        position={[0, 1.95, 0]}
        size={1.6}
      />
      <mesh position={[0, -2.5, 0]}>
        <ringGeometry args={[1.9, 1.94, 90]} />
        <meshBasicMaterial color={p.accent} transparent opacity={0.35} />
      </mesh>
    </Scene3D>
  );
};
