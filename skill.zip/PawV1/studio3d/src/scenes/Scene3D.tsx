// Shared 3D scaffolding for every PawV1 scene: gradient backdrop, ThreeCanvas,
// lights, fog, vignette. Children are @react-three/fiber elements.
import React from 'react';
import { AbsoluteFill, useVideoConfig } from 'remotion';
import { ThreeCanvas } from '@remotion/three';
import { pal } from '../lib/theme';
import type { Look } from '../lib/types';

export const Scene3D: React.FC<{
  look: Look;
  children: React.ReactNode;
  camera?: { position: [number, number, number]; fov?: number };
  fog?: [number, number];
}> = ({ look, children, camera, fog }) => {
  const { width, height } = useVideoConfig();
  const p = pal(look);
  const pos = camera?.position ?? [0, 0.4, 8];
  const fov = camera?.fov ?? 50;
  return (
    <AbsoluteFill
      style={{
        background: `radial-gradient(120% 120% at 50% 0%, ${p.bgB} 0%, ${p.bgA} 70%)`,
      }}
    >
      <ThreeCanvas
        width={width}
        height={height}
        style={{ position: 'absolute', top: 0, left: 0 }}
        camera={{ position: pos, fov, near: 0.1, far: 120 }}
        gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
      >
        <fog attach="fog" args={[p.fog, fog?.[0] ?? 12, fog?.[1] ?? 46]} />
        <ambientLight intensity={0.9} />
        <directionalLight position={[4, 6, 6]} intensity={1.6} color={p.text} />
        <directionalLight position={[-6, -2, -4]} intensity={0.8} color={p.accent} />
        <pointLight position={[0, 2, 6]} intensity={30} distance={30} color={p.secondary} />
        {children}
      </ThreeCanvas>
      <AbsoluteFill
        style={{
          background: `radial-gradient(100% 100% at 50% 50%, transparent 55%, rgba(0,0,0,0.38) 100%)`,
          pointerEvents: 'none',
        }}
      />
    </AbsoluteFill>
  );
};

// Big in-scene text as a 3D plane (canvas texture, no font geometry needed).
export const TextPlane: React.FC<{
  text: string;
  color: string;
  font?: string;
  size?: number;      // max world height of the text block
  maxW?: number;      // max world width
  position?: [number, number, number];
  opacity?: number;
}> = ({ text, color, font = 'InterBlack', size = 1.6, maxW = 9.5, position = [0, 0, 0], opacity = 1 }) => {
  const { tex, aspect } = React.useMemo(() => makeTextTexture(text, color, font), [text, color, font]);
  const h = Math.min(size, maxW / aspect);
  const w = h * aspect;
  return (
    <mesh position={position}>
      <planeGeometry args={[w, h]} />
      <meshBasicMaterial map={tex} transparent opacity={opacity} toneMapped={false} />
    </mesh>
  );
};

export const makeTextTexture = (
  text: string,
  color: string,
  font: string
): { tex: THREE.Texture; aspect: number } => {
  const meas = document.createElement('canvas').getContext('2d')!;
  const fam = `"${font}", "Arial Black", sans-serif`;
  meas.font = `96px ${fam}`;
  const words = text.split(' ');
  const lines: string[] = [];
  let cur = '';
  for (const w of words) {
    const t = cur ? cur + ' ' + w : w;
    if (meas.measureText(t).width > 1800 && cur) {
      lines.push(cur);
      cur = w;
    } else cur = t;
  }
  if (cur) lines.push(cur);
  if (lines.length > 3) {
    lines.length = 3;
    lines[2] = lines[2].replace(/\s+\S*$/, '') + '…';
  }
  const widest = Math.max(...lines.map((l) => meas.measureText(l).width), 1);
  const lh = 120;
  const pad = 70;
  const canvas = document.createElement('canvas');
  canvas.width = Math.min(2048, Math.ceil(widest + pad * 2));
  canvas.height = Math.min(512, Math.ceil(lines.length * lh + pad * 2));
  const ctx = canvas.getContext('2d')!;
  ctx.font = `96px ${fam}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = color;
  ctx.shadowColor = color;
  ctx.shadowBlur = 24;
  const y0 = canvas.height / 2 - ((lines.length - 1) * lh) / 2;
  lines.forEach((ln, i) => ctx.fillText(ln, canvas.width / 2, y0 + i * lh));
  const tex = new THREE.CanvasTexture(canvas);
  tex.anisotropy = 4;
  tex.needsUpdate = true;
  return { tex, aspect: canvas.width / canvas.height };
};

import * as THREE from 'three';
