// burst3d - particle sphere explodes outward, shock rings expand. For impact lines,
// numbers, big claims.
import React from 'react';
import { useCurrentFrame, useVideoConfig, interpolate } from 'remotion';
import * as THREE from 'three';
import { Scene3D, TextPlane } from './Scene3D';
import { mulberry } from './bits';
import { pal } from '../lib/theme';
import type { Look } from '../lib/types';

export const Burst3D: React.FC<{ look: Look; text: string; keyword?: string }> = ({ look, text }) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const p = pal(look);
  const t = frame / fps;

  const COUNT = 700;
  const [dirs] = React.useMemo(() => {
    const r = mulberry(99);
    const arr = new Float32Array(COUNT * 3);
    for (let i = 0; i < COUNT; i++) {
      const th = r() * Math.PI * 2;
      const ph = Math.acos(2 * r() - 1);
      arr[i * 3] = Math.sin(ph) * Math.cos(th);
      arr[i * 3 + 1] = Math.cos(ph);
      arr[i * 3 + 2] = Math.sin(ph) * Math.sin(th);
    }
    return [arr];
  }, []);
  const speedJitter = React.useMemo(() => {
    const r = mulberry(100);
    return Array.from({ length: COUNT }, () => 0.7 + r() * 0.75);
  }, []);

  const positions = React.useMemo(() => new Float32Array(COUNT * 3), []);
  const geoRef = React.useRef<THREE.BufferGeometry>(null);
  // update positions deterministically from frame
  {
    const boom = t * 3.1;
    for (let i = 0; i < COUNT; i++) {
      const d = boom * speedJitter[i];
      positions[i * 3] = dirs[i * 3] * d;
      positions[i * 3 + 1] = dirs[i * 3 + 1] * d * 0.9;
      positions[i * 3 + 2] = dirs[i * 3 + 2] * d;
    }
    if (geoRef.current) {
      (geoRef.current.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    }
  }

  const ringScale = (delay: number) => Math.max(0.001, (t - delay) * 4.4);
  const ringOpacity = (delay: number) =>
    interpolate(t - delay, [0, 0.15, 1.6], [0, 0.55, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const flash = interpolate(t, [0, 0.12, 0.5], [1, 0.35, 0], { extrapolateRight: 'clamp' });

  return (
    <Scene3D look={look} camera={{ position: [0, 0.6, 8.2], fov: 52 }}>
      <pointLight intensity={flash * 220} distance={26} color={p.accent} position={[0, 0, 1]} />
      <points>
        <bufferGeometry ref={geoRef}>
          <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        </bufferGeometry>
        <pointsMaterial color={p.particle} size={0.055} sizeAttenuation transparent opacity={0.9} />
      </points>
      {[0, 0.5, 1.1].map((d, i) => (
        <mesh key={i} scale={ringScale(d)}>
          <torusGeometry args={[1, 0.02, 8, 100]} />
          <meshBasicMaterial color={i % 2 ? p.secondary : p.accent} transparent opacity={ringOpacity(d)} />
        </mesh>
      ))}
      <mesh scale={interpolate(t, [0, 0.4], [0.2, 1.5], { extrapolateRight: 'clamp' })}>
        <icosahedronGeometry args={[0.7, 2]} />
        <meshStandardMaterial
          color={p.primary} emissive={p.primary} emissiveIntensity={0.9 + flash}
          metalness={0.4} roughness={0.3}
        />
      </mesh>
      <TextPlane text={text} color={p.text} position={[0, 2.2, 0]} size={1.2} />
    </Scene3D>
  );
};
