// PawV1 karaoke captions - word-synced, driven by words.json timings.
// Active word: accent color + pop scale. Grouped into max-2-lines chunks.
import React from 'react';
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate } from 'remotion';
import { CAPTION_FONT, pal } from '../lib/theme';
import type { PawProps } from '../lib/types';

interface CapWord { w: string; s: number; e: number; }

export const Captions: React.FC<PawProps> = (props) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = pal(props.look);
  const t = frame / fps;

  const groups = React.useMemo(() => buildGroups(props), [props]);
  const active = groups.find((g) => t >= g.t0 - 0.12 && t <= g.t1 + 0.35);
  if (!active) return null;

  return (
    <AbsoluteFill style={{ justifyContent: 'flex-end', paddingBottom: props.height * 0.085, pointerEvents: 'none' }}>
      <div
        style={{
          display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '0 14px',
          padding: '0 8%', rowGap: 6,
        }}
      >
        {active.words.map((cw, i) => {
          const isActive = t >= cw.s - 0.02 && t < cw.e + 0.05;
          const spoken = t >= cw.e;
          const pop = interpolate(t, [cw.s - 0.08, cw.s + 0.06], [0.72, 1], {
            extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
          });
          const scale = isActive ? 1 + interpolate(t, [cw.s, cw.s + 0.09], [0.1, 0], { extrapolateRight: 'clamp' }) : pop;
          return (
            <span
              key={i}
              style={{
                fontFamily: `"${CAPTION_FONT}", "Arial Black", sans-serif`,
                fontSize: props.height * 0.058,
                lineHeight: 1.16,
                textTransform: 'uppercase',
                color: isActive ? p.accent : spoken ? p.caption : p.caption,
                opacity: spoken || isActive ? 1 : 0.42,
                transform: `scale(${scale})`,
                transformOrigin: 'center bottom',
                textShadow: isActive
                  ? `0 0 24px ${p.accent}, 0 3px 0 rgba(0,0,0,0.55)`
                  : '0 3px 0 rgba(0,0,0,0.5)',
                transition: 'none',
                whiteSpace: 'pre',
              }}
            >
              {cw.w + ' '}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

// Split each line's words into caption groups of <= 5 words / <= 3.4 s, snapped to pauses.
const buildGroups = (props: PawProps) => {
  const byLine = new Map<number, CapWord[]>();
  for (const w of props.words) {
    if (!byLine.has(w.line)) byLine.set(w.line, []);
    byLine.get(w.line)!.push({ w: w.w, s: w.s, e: w.e });
  }
  const groups: Array<{ t0: number; t1: number; words: CapWord[] }> = [];
  for (const [li, ws] of byLine) {
    ws.sort((a, b) => a.s - b.s);
    let cur: CapWord[] = [];
    for (let i = 0; i < ws.length; i++) {
      cur.push(ws[i]);
      const dur = cur[cur.length - 1].e - cur[0].s;
      const isPause = i < ws.length - 1 && ws[i + 1].s - ws[i].e > 0.28;
      const hardStop = /[.!?…]$/.test(ws[i].w);
      if (cur.length >= 5 || dur >= 3.4 || isPause || hardStop) {
        groups.push({ t0: cur[0].s, t1: cur[cur.length - 1].e, words: cur });
        cur = [];
      }
    }
    if (cur.length) {
      const lt = props.lineTimes[li];
      groups.push({ t0: cur[0].s, t1: cur[cur.length - 1].e + (lt ? (lt.end - cur[cur.length - 1].e) * 0.4 : 0.2), words: cur });
    }
  }
  return groups.sort((a, b) => a.t0 - b.t0);
};
