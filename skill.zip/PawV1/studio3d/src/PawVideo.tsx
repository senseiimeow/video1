// PawV1 main composition: sequences of 3D scenes synced to spoken lines + karaoke captions.
// Audio is NOT rendered here (chunks render muted); tools/make.py muxes the mixed track after concat.
import React from 'react';
import { AbsoluteFill, Sequence, useVideoConfig, interpolate, useCurrentFrame } from 'remotion';
import type { PawProps, SceneKind } from './lib/types';
import { Hero3D } from './scenes/Hero3D';
import { Orbit3D } from './scenes/Orbit3D';
import { Grid3D } from './scenes/Grid3D';
import { Burst3D } from './scenes/Burst3D';
import { Wave3D } from './scenes/Wave3D';
import { Outro3D } from './scenes/Outro3D';
import { Captions } from './captions/Captions';

const SCENES: Record<SceneKind, React.FC<{ look: PawProps['look']; text: string; keyword?: string }>> = {
  hero3d: Hero3D,
  orbit3d: Orbit3D,
  grid3d: Grid3D,
  burst3d: Burst3D,
  wave3d: Wave3D,
  outro3d: Outro3D,
};

export interface Span { kind: SceneKind; from: number; dur: number; line: number; }

// scene i covers [lineStart_i - lead, lineStart_{i+1} - lead] (last one runs to end)
export const buildSpans = (props: PawProps, fps: number): Span[] => {
  const n = props.lines.length;
  const out: Span[] = [];
  for (let i = 0; i < n; i++) {
    const startS = Math.max(0, props.lineTimes[i].start - props.lead);
    const endS =
      i + 1 < n
        ? Math.max(startS + 0.6, props.lineTimes[i + 1].start - props.lead * 0.4)
        : props.duration;
    const from = Math.round(startS * fps);
    const to = Math.round(endS * fps);
    if (to <= from) continue;
    out.push({ kind: props.lines[i].scene || 'orbit3d', from, dur: to - from, line: i });
  }
  return out;
};

const FadeOut: React.FC = () => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const opacity = interpolate(frame, [durationInFrames - 14, durationInFrames - 1], [0, 1], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
  });
  return <AbsoluteFill style={{ background: '#000', opacity }} pointerEvents="none" />;
};

export const PawVideo: React.FC<PawProps> = (props) => {
  const { fps } = useVideoConfig();
  const spans = buildSpans(props, fps);
  return (
    <AbsoluteFill style={{ background: '#000' }}>
      {spans.map((s, i) => {
        const Scene = SCENES[s.kind] ?? Orbit3D;
        const line = props.lines[s.line];
        return (
          <Sequence key={i} from={s.from} durationInFrames={s.dur} name={`L${s.line}-${s.kind}`}>
            <Scene look={props.look} text={line.text} keyword={line.keyword} />
          </Sequence>
        );
      })}
      <Sequence from={0} durationInFrames={Infinity} name="captions" layout="none">
        <Captions {...props} />
      </Sequence>
      <FadeOut />
    </AbsoluteFill>
  );
};
