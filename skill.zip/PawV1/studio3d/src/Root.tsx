// PawV1 Remotion root. One composition: Paw3D.
// Duration/size come from data.json (passed with --props), so tools never touch JSX.
import React from 'react';
import { Composition, getInputProps } from 'remotion';
import { PawVideo } from './PawVideo';
import type { PawProps } from './lib/types';
import { ensureFonts } from './load-fonts';

ensureFonts();

export const RemotionRoot: React.FC = () => {
  const props = getInputProps() as PawProps;
  const fps = props?.fps || 30;
  const width = props?.width || 1280;
  const height = props?.height || 720;
  const duration = Math.max(
    30,
    Math.ceil(((props?.duration ?? 5) * fps + 2) as number)
  );
  return (
    <Composition
      id="Paw3D"
      component={PawVideo}
      durationInFrames={duration}
      fps={fps}
      width={width}
      height={height}
      defaultProps={props && props.lines ? props : undefined}
      calculateMetadata={({ props: p }) => ({
        durationInFrames: Math.max(30, Math.ceil((p.duration ?? 5) * fps) + 2),
      })}
    />
  );
};
