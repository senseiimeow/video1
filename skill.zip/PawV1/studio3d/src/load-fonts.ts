// Loads local fonts from public/fonts before any frame renders.
// Remotion pattern: delayRender so the bundler waits until fonts are ready.
import { staticFile, delayRender } from 'remotion';

let done = false;

export const ensureFonts = (): boolean => {
  if (done) return true;
  done = true;
  const load = async () => {
    const fonts: Array<[string, string]> = [
      ['InterBlack', 'fonts/Inter-Black.otf'],
      ['InterXBold', 'fonts/Inter-ExtraBold.otf'],
    ];
    for (const [family, file] of fonts) {
      try {
        const face = new FontFace(family, `url(${staticFile(file)})`);
        const loaded = await face.load();
        document.fonts.add(loaded);
      } catch {
        // font missing - fall back to system sans-serif, still renders
      }
    }
  };
  const handle = delayRender('fonts');
  void load().finally(() => {
    // give the font stack one paint to settle
    requestAnimationFrame(() => continueRender(handle));
  });
  return false;
};

// imported after use to avoid TDZ issues in bundling
import { continueRender } from 'remotion';
