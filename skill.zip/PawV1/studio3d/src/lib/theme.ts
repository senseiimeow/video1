// PawV1 studio3d - color looks. One look = one mood. Add yours here.
import type { Look } from './types';

export interface Palette {
  bgA: string;        // background gradient top
  bgB: string;        // background gradient bottom
  fog: string;        // scene fog color
  primary: string;    // main 3D material color
  secondary: string;  // orbiting / secondary objects
  accent: string;     // captions highlight, glow, wireframes
  text: string;       // in-scene text color
  caption: string;    // caption base color
  particle: string;   // star / particle color
}

export const LOOKS: Record<Look, Palette> = {
  neon: {
    bgA: '#07020f', bgB: '#160a2e', fog: '#0a0318',
    primary: '#7c3aed', secondary: '#22d3ee', accent: '#f0abfc',
    text: '#ffffff', caption: '#ffffff', particle: '#c4b5fd',
  },
  sunset: {
    bgA: '#1a0500', bgB: '#3d0f1e', fog: '#20060a',
    primary: '#f97316', secondary: '#fb7185', accent: '#fde047',
    text: '#fff7ed', caption: '#fff7ed', particle: '#fdba74',
  },
  midnight: {
    bgA: '#020617', bgB: '#0b1e3a', fog: '#030814',
    primary: '#38bdf8', secondary: '#fbbf24', accent: '#f8fafc',
    text: '#f0f9ff', caption: '#f0f9ff', particle: '#7dd3fc',
  },
  candy: {
    bgA: '#fdf2f8', bgB: '#e0f2fe', fog: '#fdf2f8',
    primary: '#ec4899', secondary: '#818cf8', accent: '#14b8a6',
    text: '#1e1b4b', caption: '#1e1b4b', particle: '#f9a8d4',
  },
};

export const pal = (look: Look): Palette => LOOKS[look] ?? LOOKS.neon;

export const CAPTION_FONT = 'InterBlack';
export const UI_FONT = 'InterXBold';
