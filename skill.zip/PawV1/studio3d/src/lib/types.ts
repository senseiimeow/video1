// PawV1 studio3d data contract - written by tools/plan.py, consumed by the Remotion comp.
// Times are SECONDS; the comp converts to frames with props.fps.

export type Look = 'neon' | 'sunset' | 'midnight' | 'candy';
export type SceneKind = 'hero3d' | 'orbit3d' | 'grid3d' | 'burst3d' | 'wave3d' | 'outro3d';

export interface PawLine {
  text: string;          // exactly what is spoken (numbers written the way they are said)
  scene: SceneKind;      // which 3D scene renders during this line
  gap?: number;          // extra pause AFTER this line, seconds
  keyword?: string;      // optional short word shown as a floating 3D chip in non-hero scenes
}

export interface LineTime {
  start: number;         // seconds, when the line's speech starts (after lead silence trim)
  end: number;           // seconds, when the line's speech ends
}

export interface Word {
  w: string;             // the word (script spelling)
  line: number;          // index into lines[]
  s: number;             // spoken start, seconds
  e: number;             // spoken end, seconds
}

export interface PawProps {
  title: string;
  look: Look;            // color theme
  lead: number;          // silence before first line, seconds
  outro: number;         // silence after last line, seconds
  lines: PawLine[];
  lineTimes: LineTime[]; // same length as lines
  words: Word[];         // word-level timings (karaoke captions)
  duration: number;      // total video length in seconds
  fps: number;
  width: number;
  height: number;
}

export const DEFAULT_PROPS: PawProps = {
  title: 'PawV1',
  look: 'neon',
  lead: 0.4,
  outro: 1.2,
  lines: [{ text: 'PawV1 turns a script into a three D animated video.', scene: 'hero3d' }],
  lineTimes: [{ start: 0.4, end: 3.2 }],
  words: [],
  duration: 4.8,
  fps: 30,
  width: 1280,
  height: 720,
};
