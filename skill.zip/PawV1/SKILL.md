---
name: PawV1
description: Super skill for video work on any machine, zero paid APIs. Five modes - (S) scriptforge niche menu -> 10 ideas -> 450-600 word faceless script, ready to render; (C) studio3d turn a voice recording OR a text script into a finished 3D animated video (three.js scenes + Remotion captions/audio/rendering, word-synced karaoke captions, Kokoro TTS voice, procedural music, -14 LUFS MP4); (D) studio2d turn a voiceover into a cinematic stick-figure story video (GrowKaz Stickman Studio - rim-lit 2D characters, 2.5D sets, bigFace close-ups, blueprint/data graphics, three.js 3D shots, 5 colour styles, auto Whisper timestamps, generated music + SFX, 16:9 or 9:16, 720p-4K); (B) faceless-shorts turn a script into a code-drawn vertical short in 6 styles; (A) ai-video-editor cut a talking-head video and add motion graphics in 7 styles. Use when the user sends a voice note, a script, a video file, or asks for 3D animated / stick-figure / faceless / edited videos.
---

# PawV1

One skill, four video pipelines. Everything runs locally: Whisper (faster-whisper) for
transcription and word timings, Kokoro-82M ONNX for the voice, three.js for 3D scenes,
Remotion for captions + rendering, headless Chromium + canvas for stick-figure frames,
numpy for music and mixing, ffmpeg for the final file.
No account, no API key, no GPU required (software WebGL).

`SKILL` below means this skill's folder (the one containing this file). All commands are
run from that folder. Every tool prints JSON or a short report - read it before the next step.

## Mode map - pick by INPUT, not by guess

| User gives you | Mode | Entry command |
| --- | --- | --- |
| A voice recording (or says "main voice note bhejta hoon") **or** a text script, wants a 3D animated video | **C studio3d** | `python3 SKILL/studio3d/tools/make.py ...` |
| A voiceover (or voice note) and wants a **cinematic stick-figure story video** (characters, sets, close-ups, story) | **D studio2d** | `cd SKILL/studio2d && python3 tools/new_project.py ...` |
| A text script, wants a vertical faceless short in a named visual style | B shorts | `bash SKILL/shorts/scripts/new_video.sh <style> <name> --dir <proj>` |
| A raw talking-head video file to cut / caption / add graphics to | A editor | `python3 SKILL/scripts/transcribe.py "VIDEO"` |
| "I want ideas / a script for a faceless channel" (no input file yet) | **S scriptforge** | `python3 SKILL/scriptforge/tools/scriptforge.py niches` |

Default when the user just says "make a video from this": **Mode C** - it is the fastest
path from voice/script to a finished MP4 and needs no per-style project.
Pick **Mode D** when the user says "stickman/stick figure video", "animated story",
"What If style", or wants characters and scenes acting out the narration.

## 0. Setup (first time on a machine)

```
python3 SKILL/scripts/paw_setup.py --check      # prints JSON, one line per dependency
```

What must exist (the checker tells you the exact fix for each):

1. **ffmpeg** on PATH. Not installed? `winget install Gyan.FFmpeg` (Windows),
   `brew install ffmpeg` (macOS), `sudo apt install ffmpeg` (Debian/Ubuntu).
2. **Node >= 18 + npm** (Mode C only). `node --version`.
3. **studio3d npm packages** (Mode C): `cd SKILL/studio3d && npm install` (one command,
   ~260 packages, ~25 s). Pin reminder: the tested set is remotion@4.0.542,
   @remotion/three@4.0.542, @react-three/fiber@9.8.2, react@19.3.x, three@0.180.x -
   `package.json` already pins them, do not upgrade blindly.
4. **Browser for Remotion**: it needs the old-headless `chrome-headless-shell`
   (full Chrome >= 132 removed old headless and will NOT work). `remotion.config.js`
   looks for it at `~/.cache/ms-playwright/chromium_headless_shell-*/chrome-headless-shell-linux64/chrome-headless-shell`
   (Playwright's download) - if absent run `npx playwright install chromium-headless-shell`
   or `npx remotion browser ensure`. Override anytime with the `PAW_CHROME` env var.
5. **Mode D studio (GrowKaz Stickman, one time)**: `cd SKILL/studio2d && npm install &&
   npx playwright install chromium` (its own full-Chromium build, separate from Remotion's
   headless shell), then `python3 tools/verify_kit.py` must print 29/29 and
   `python3 tools/doctor.py` must be all OK. Projects can live anywhere - run the studio
   tools from the studio root and pass `--project /abs/path/projects/<slug>`.
6. **Python deps**: `pip install -r SKILL/requirements.txt` (faster-whisper, numpy, scipy,
   playwright, pillow). Mode C's voice/words/music steps run inside a private venv at
   `~/.faceless-shorts/venv` (created once by `bash SKILL/shorts/scripts/setup.sh`,
   env `FACELESS_HOME=~/.faceless-shorts`).
7. **Models (downloaded once)**: Kokoro ~340 MB to `$FACELESS_HOME/kokoro/`
   (`python3 SKILL/shorts/scripts/voice.py --download`), Whisper small.en + large-v3-turbo
   ~2 GB to `~/.cache/huggingface` (auto-downloads on first use).

`--check` exits 0 when Modes C and D can run end to end. Run it, fix what it names, run again.

## 1. Mode C - studio3d (voice/script -> 3D animated MP4)

### The one command

```
python3 SKILL/studio3d/tools/make.py --name my-video --script script.txt
python3 SKILL/studio3d/tools/make.py --name my-video --text "Line one. Line two. Line three."
python3 SKILL/studio3d/tools/make.py --name my-video --voice recording.m4a --lang en
python3 SKILL/studio3d/tools/make.py --name my-video --script s.txt --look sunset --size vertical
```

Pipeline it runs: plan -> voice -> word timings -> music+mix -> export -> Remotion render
(9 s chunks, muted video) -> concat -> mux audio -> loudnorm -14 LUFS -> final MP4.
On 2 CPU cores a 30 s 720p video takes **about 3 minutes** end to end (~0.16 s/frame).

Useful flags: `--look neon|sunset|midnight|candy` (palette), `--voice-name am_michael`
(see `python3 SKILL/shorts/scripts/voice.py --list` for the 10 good voices),
`--speed 1.1` (TTS pace), `--size 720p|vertical|square|1080p`, `--fps 30`,
`--pattern orbit3d,grid3d,wave3d,burst3d` (middle-scene rotation),
`--out /path/final.mp4` (also copy there), `--skip-render` (stop after the plan/voice/
music stages), `--resume-render` (start a later call directly at the render step).

### Input rules (this is where quality is won)

- **One line = one cut = one sentence.** A long thought may span several lines; each line
  is spoken in ONE TTS pass so intonation flows, and cuts snap to pauses between them.
- Write numbers the way they are SAID: "3D" -> "three D", "30s" -> "thirty seconds".
- 8-16 words per line is the sweet spot. Hook first, payoff last, CTA in the outro.
- **Voice input**: the recording IS the narration. It is transcribed (Whisper), the
  transcript becomes the lines (auto scenes assigned), and word timings are aligned to
  the user's actual voice. `--lang hi` switches to large-v3-turbo for Hindi/Hinglish.
- If the user gave only a topic ("how to X with model Y"), YOU write the 6-9 lines, show
  them, get a yes, then run make.py.

### What you get on disk

Project folder `~/pawv1-projects/<name>/`:
- `script.json` - lines + scene per line + voice settings (edit and re-run to iterate)
- `data/narration.wav` `data/lines.json` (exact line start/end, seconds)
  `data/words.json` [{w, line, s, e}] (word timings) `data/audio.wav` (voice+music mix)
- `render/` - muted video chunks (cached, resumable) and `video_full.mp4`
- `<name>.mp4` - THE final video (h264 + AAC, loudnorm -14 LUFS, faststart)

Render inputs are exported to `SKILL/studio3d/public/`: `data.json` (the full prop
payload: lines, lineTimes, words, look, duration, fps, size), `audio.wav`, `narration.wav`.

### Scenes (three.js, all deterministic per frame)

`hero3d` (opening statement + icosahedron hero), `orbit3d` (torus-knot core, orbiting
satellites), `grid3d` (cyber grid fly-through + cubes), `wave3d` (flowing wave mesh +
orbs), `burst3d` (particle explosion + shock rings - numbers, big claims, "!"), `outro3d`
(pulling back from a spinning knot, CTA). Scene choice is automatic: first line hero3d,
last outro3d, middle lines cycle the pattern; lines with "N seconds/percent/x/million"
or ending "!" get burst3d. Override per line in `script.json` (`"scene": "..."`).

Add a scene = one file in `SKILL/studio3d/src/scenes/` (copy an existing one, animate
only from `useCurrentFrame()`), register it in `SCENES` inside `src/PawVideo.tsx`, add
the id to `SceneKind` in `src/lib/types.ts` and to plan.py's valid set. Nothing else.

### Iterating

- Text/scene/voice changes: edit `script.json` (or the input) -> re-run make.py (same
  command; it regenerates audio + data.json; old chunks are invalidated automatically
  only if data.json changed - when unsure delete `render/chunk_*.mp4`).
- Look-only changes: edit `look` in `script.json`, re-run, delete chunks (palette lives
  inside the rendered frames).
- Inspect one frame without a full render:
  `cd SKILL/studio3d && npx remotion still Paw3D out.png --props=public/data.json --frame=100`
- Play interactively (desktop): `cd SKILL/studio3d && npx remotion studio`.

## 2. Mode D - studio2d (voiceover -> cinematic stick-figure story MP4)

The GrowKaz Stickman Studio, bundled at `SKILL/studio2d/`. A voiceover becomes an animated
stick-figure film: every frame is code-drawn (canvas 2D + three.js) in headless Chromium,
Whisper gives word timings, music/SFX are synthesised, mixed to -14 LUFS and muxed.
Style bible, engine API, story breakdown, sound design and QC docs live in
`SKILL/studio2d/docs/references/` - READ `style-bible.md` + `engine-api.md` +
`story-breakdown.md` before writing any shot. Stage-by-stage guides are `docs/stages/*.md`.

### Pipeline (run tools from `SKILL/studio2d/`)

```bash
cd SKILL/studio2d
# 1) project (projects/ is created relative to CWD - pass an absolute --project everywhere after)
python3 tools/new_project.py --name my-story --voice /abs/voice.mp3 [--script /abs/script.txt] \
    --aspect 16:9 --resolution 1080p --title "My Story" [--captions]
# 2) timings: timestamped script -> parse_script.py | plain script or audio only -> transcribe.py
python3 tools/transcribe.py --project projects/my-story --lang en --model small   # or --script input/script.txt
python3 tools/beats.py --project projects/my-story          # beat sheet + draft story/shots.json
# 3) YOU write story/bible.md, scenes/cast.js, scenes/sets/*.js, scenes/shots/NN_*.js,
#    and rewrite story/shots.json (ids, timings, music moods, sfx cues)
# 4) QC loop - LOOK at every sheet before rendering:
node render.mjs --project projects/my-story --sheet --scale 0.5      # one still per shot
node render.mjs --project projects/my-story --from 0 --to 30 --scale 0.5   # moving preview
# 5) final render + sound
node render.mjs --project projects/my-story                 # -> build/video_silent.mp4
python3 audio/mix.py --project projects/my-story            # -> out/<title>.mp4 (music+SFX+ducking)
```

### Mode D rules

- **Never change the spoken words.** Shots illustrate the narration; cuts land 0.1-0.2 s
  before their phrase starts. 15-25 shots/minute, median shot 2-3.5 s, one camera move per
  shot, rim light on every lit figure, colours only from `mood()`/`S()`, `V(h,v)` for every
  aspect-dependent value, no `Math.random`/`Date.now` (deterministic frames only).
- **Styles**: `emerald` (default), `ember`, `arctic`, `sakura`, `retro` - compare with
  `node render.mjs --project P --styles a,b,c,d,e --at t1,t2,t3 --scale 0.5`, pick in
  `config.json`. 9:16 needs a fresh sheet review after switching aspect.
- **Sandbox**: default `--workers` is `cpus/2`; on a 2-core box that is 1 worker,
  ~2 frames/s at 720p (1080p ~2x slower, 4K ~8x). Keep renders in the FOREGROUND -
  background processes get killed. Re-run the same command to resume nothing - render.mjs
  restarts the range, so prefer rendering shot ranges with `--from/--to` when iterating.
- QC before delivering: `ffprobe` duration == shots.json duration, audio stream present,
  contact sheet of the final file looks right (see `docs/references/render-qc.md`).

## 3. Mode B - faceless-shorts (script -> styled vertical short)

```
bash SKILL/shorts/scripts/new_video.sh <style> <name> --dir <target>
```
Styles: `deep-dive` (3D three.js), `night-file` (3D dark mystery), `inside-out` (2D x-ray),
`stick-story` (2D stick figure), `paper-atlas` (2D paper history maps), `tall-tale` (3D
sunshine cartoon). The script walks you through: write `script.json` -> `voice.py` ->
`words.py` -> `capture.mjs check|cues|sheet|video` -> `mix.py` -> done. Read the style's
`STYLE.md` before drawing anything. 3D styles on CPU need
`SOFTWARE_GL=1 QS='&res=0.6&aa=0&shadow=1024' FPS=24` (~2.3 s/frame).

## 4. Mode A - ai-video-editor (talking-head edit)

`python3 SKILL/scripts/transcribe.py "VIDEO" --lang en|hi|auto` creates `<video>_edit/`
with transcript.txt; then follow SKILL/scripts and the 7 styles in `SKILL/styles/`
(cut list -> approval -> graphics plan -> stills -> final render via `scripts/render.py`).
Ask the user the setup questions from the original flow (cut silences? mistakes? style?
captions?) before cutting anything.

## 5. Mode S - ScriptForge (niche -> 10 ideas -> 450-600 word script)

ScriptForge is PawV1's scripting layer (from the user's "2D Niche Prompt for Claude.pdf").
When the user has NO input yet and asks for ideas or a script for a faceless channel,
**become ScriptForge** by following `SKILL/scriptforge/PROMPT.md` exactly: 3 steps, never
skipping, waiting for the user's choice each time:

1. **Niche selection** - show the 5x5 menu (Self-Improvement / Psychology / What If /
   Science / History). CLI: `python3 SKILL/scriptforge/tools/scriptforge.py niches`.
2. **10 content ideas** - clickable titles <60 chars + one-line hook each, mixed formats.
   CLI scaffold: `... scriptforge.py ideas 3.2` (sharpen the titles, don't paste raw).
3. **Full script** - 450-600 words (~3-4 min at 150 wpm), narration style matched to the
   niche, HOOK/SETUP/MAIN BODY/PAYOFF/OUTRO with timestamps, [NARRATION] + [VISUAL] cues,
   then 3 alt titles, thumbnail text, 5 tags, word count + runtime. Offer: "Want edits, a
   different tone, a Shorts version (60s), or a new topic?"

Rules that are non-negotiable: facts accurate (never invent statistics/quotes/studies),
write for the ear, every line earns attention, manipulation topics framed for awareness.

**Bridge to video**: clean the [NARRATION] text and route by length -
`python3 SKILL/scriptforge/tools/scriptforge.py check narration.txt` prints word count,
runtime and the exact Mode C/D/B command (<=75s -> studio3d `--size vertical`; ~3-4 min ->
studio3d `--size 720p` or Mode B/D; longer -> split into parts).

## 6. Sandboxed / CI environments - READ BEFORE RENDERING

- **Long renders must run in the foreground.** Background processes are killed by many
  sandboxes. make.py already renders 9-second chunks in the foreground; if a call dies,
  **re-run the same command** - finished chunks are cached and only the rest renders.
  Chunk size is `--chunk-sec` (lower it to 5 if your command timeout is tight).
- **OOM**: default `--concurrency 1` is deliberate (2 tabs x SwiftShader x 720p can OOM
  a 4 GB sandbox). Raise only on real machines.
- **Software WebGL** is used (no GPU): Chromium falls back to SwiftShader automatically;
  the deprecation warning in the logs is harmless. If frames come out black, pass
  `--gl=angle` via `npx remotion render` or set `PAW_CHROME` to a headless shell build.
- `npx` must be on PATH where you invoke make.py; run `node --version` once to confirm.

## 7. Performance reference (2 vCPU, 4 GB, software WebGL)

- TTS: ~8x realtime. Word alignment (small.en): ~0.5x realtime. Music+mix: < 5 s.
- Remotion render 720p30, concurrency 1: **0.14-0.16 s/frame** (~160 s for 1000 frames).
- 30 s video end to end (script given): ~3 min. First run adds one-time model downloads.
- Mode D stickman render: ~2 frames/s at 720p24 per worker (SwiftShader CPU); a 30 s
  720p video ~ 4-6 min + transcription. Sheet/still QC passes take seconds - always
  iterate on sheets, render the full video only after every shot passes.

## 8. Agent rules (the 50x part)

1. Check once: `python3 SKILL/scripts/paw_setup.py --check`.
2. Never ask the user for formats they already gave: voice note -> Mode C with --voice;
   script text -> Mode C with --script/--text. Ask only about look/size/voice if it matters.
3. Show the 7-9 written lines before rendering when you authored the script yourself.
4. One project = one `--name`; reuse the name to iterate, don't spawn duplicates.
5. Deliver the final MP4 path + duration + the scene list from the JSON summary.
6. If a render fails mid-way: run the SAME command again before changing anything.
7. Mode D: a voice note asking for a story/animated/stickman video -> studio2d; keep the
   narration word-for-word, do the sheet QC loop, and render foreground-only.
