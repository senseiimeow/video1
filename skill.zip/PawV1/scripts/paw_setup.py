"""PawV1 unified setup check - run before first use, prints one JSON blob.

  python3 scripts/paw_setup.py --check
  python3 scripts/paw_setup.py --install-node      # cd studio3d && npm install
  python3 scripts/paw_setup.py --install-shell     # npx playwright install chromium-headless-shell
  python3 scripts/paw_setup.py --download-kokoro   # Kokoro TTS models (~340 MB, once)

Exit code 0 = Modes C and D can run end to end. Each entry names the exact fix.
"""
import json, os, shutil, subprocess, sys
from pathlib import Path

SKILL = Path(__file__).resolve().parent.parent
STUDIO = SKILL / 'studio3d'
STUDIO2D = SKILL / 'studio2d'
HOME = Path(os.environ.get('FACELESS_HOME', Path.home() / '.faceless-shorts'))
VENV_PY = HOME / 'venv' / 'bin' / 'python'


def ver(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=30).stdout.strip().splitlines()[0]
    except Exception:
        return None


def main():
    install_node = '--install-node' in sys.argv
    install_shell = '--install-shell' in sys.argv
    download_kokoro = '--download-kokoro' in sys.argv
    out = {}

    ff = shutil.which('ffmpeg')
    out['ffmpeg'] = {'ok': bool(ff), 'version': ver(['ffmpeg', '-version']) if ff else None,
                     'fix': None if ff else 'Windows: winget install Gyan.FFmpeg | macOS: brew install ffmpeg | Linux: sudo apt install ffmpeg'}

    node = ver(['node', '--version'])
    out['node'] = {'ok': bool(node), 'version': node,
                   'fix': None if node else 'install Node.js >= 18 from nodejs.org (Mode C only)'}

    nm = STUDIO / 'node_modules' / '.package-lock.json'
    if install_node:
        subprocess.run(['npm', 'install', '--no-audit', '--no-fund'], cwd=STUDIO, check=True)
    out['studio3d_npm'] = {'ok': nm.exists(), 'path': str(STUDIO / 'node_modules'),
                           'fix': None if nm.exists() else f'cd {STUDIO} && npm install'}

    nm2 = all((STUDIO2D / 'node_modules' / p).exists()
              for p in ('three', 'playwright', '@fontsource'))
    if install_node:
        subprocess.run(['npm', 'install', '--no-audit', '--no-fund'], cwd=STUDIO2D, check=False)
    out['studio2d_npm'] = {'ok': nm2, 'path': str(STUDIO2D / 'node_modules'),
                           'fix': None if nm2 else f'cd {STUDIO2D} && npm install'}

    chrom2 = False; chrom2_path = None
    try:
        r = subprocess.run(['node', '-e', "import('playwright').then(p=>console.log(p.chromium.executablePath()))"],
                           cwd=STUDIO2D, capture_output=True, text=True, timeout=60)
        chrom2_path = r.stdout.strip()
        chrom2 = bool(chrom2_path) and Path(chrom2_path).exists()
    except Exception:
        pass
    out['studio2d_chromium'] = {'ok': chrom2, 'path': chrom2_path,
                                'fix': None if chrom2 else f'cd {STUDIO2D} && npx playwright install chromium'}

    shells = sorted(Path.home().joinpath('.cache', 'ms-playwright').glob(
        'chromium_headless_shell-*/chrome-headless-shell-linux64/chrome-headless-shell'))
    if install_shell:
        subprocess.run(['npx', 'playwright', 'install', 'chromium-headless-shell'], check=False)
        shells = sorted(Path.home().joinpath('.cache', 'ms-playwright').glob(
            'chromium_headless_shell-*/chrome-headless-shell-linux64/chrome-headless-shell'))
    alt = Path(os.environ.get('PAW_CHROME', ''))
    ok_shell = bool(shells) or (alt.exists() and 'headless' in alt.name)
    out['chrome_headless_shell'] = {'ok': ok_shell,
                                    'path': str(shells[-1]) if shells else (str(alt) if alt.exists() else None),
                                    'fix': None if ok_shell else 'npx playwright install chromium-headless-shell  (or npx remotion browser ensure; or set PAW_CHROME)'}

    py = sys.executable
    try:
        import faster_whisper, numpy, scipy  # noqa
        out['python_deps'] = {'ok': True, 'python': py}
    except ImportError as e:
        out['python_deps'] = {'ok': False, 'missing': str(e), 'fix': f'pip install -r {SKILL}/requirements.txt'}

    kOnnx = VENV_PY.exists() and subprocess.run(
        [str(VENV_PY), '-c', 'import kokoro_onnx'], capture_output=True).returncode == 0
    kokoroFiles = all((HOME / 'kokoro' / f).exists() for f in ('kokoro-v1.0.onnx', 'voices-v1.0.bin'))
    if download_kokoro:
        subprocess.run([str(VENV_PY) if VENV_PY.exists() else py,
                        str(SKILL / 'shorts' / 'scripts' / 'voice.py'), '--download'], check=False)
        kokoroFiles = all((HOME / 'kokoro' / f).exists() for f in ('kokoro-v1.0.onnx', 'voices-v1.0.bin'))
    out['kokoro'] = {'ok': bool(kOnnx and kokoroFiles), 'venv_python': str(VENV_PY),
                     'models_dir': str(HOME / 'kokoro'),
                     'fix': None if (kOnnx and kokoroFiles) else
                     f'bash {SKILL}/shorts/scripts/setup.sh  (creates venv + downloads models, ~340 MB, once)'}

    hf = Path.home() / '.cache' / 'huggingface'
    out['whisper_cache'] = {'ok': hf.exists(), 'path': str(hf),
                            'note': 'small.en + large-v3-turbo auto-download on first use (~2 GB)'}

    ok = all(out[k]['ok'] for k in ('ffmpeg', 'node', 'studio3d_npm', 'chrome_headless_shell',
                                    'python_deps', 'kokoro'))
    out['READY_MODE_C'] = ok
    okD = all(out[k]['ok'] for k in ('ffmpeg', 'node', 'studio2d_npm', 'studio2d_chromium', 'python_deps'))
    out['READY_MODE_D'] = okD
    print(json.dumps(out, indent=1))
    sys.exit(0 if (ok and okD) else 1)


if __name__ == '__main__':
    main()
