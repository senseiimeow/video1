# PawV1 - one skill, five video pipelines (100% local, no paid APIs)

**PawV1** turns a voice recording or a text script into a finished **3D animated video**
(three.js scenes + Remotion captions/audio/rendering), a **cinematic stick-figure story
video** (GrowKaz Stickman Studio: code-drawn 2D + 3D, music + SFX), a **faceless vertical
short** (6 code-drawn styles), or an **edited talking-head video** (cuts + motion
graphics). No input yet? **ScriptForge** (Mode S) takes you niche -> 10 ideas -> a
450-600 word faceless script, then routes it straight into a render mode.

## Quickstart (Mode S - ScriptForge: no input yet, want a script first)

```bash
python3 scriptforge/tools/scriptforge.py niches        # show the 5x5 niche menu
python3 scriptforge/tools/scriptforge.py ideas 3.2     # 10 title/hook scaffolds
python3 scriptforge/tools/scriptforge.py template      # script skeleton
python3 scriptforge/tools/scriptforge.py check s.txt   # words, runtime, render command
```

The full 3-step flow (wait for the user's choice at each step) is `scriptforge/PROMPT.md`.

## Quickstart (Mode C - 3D animated video)

```bash
python3 scripts/paw_setup.py --check        # tells you exactly what is missing
cd studio3d && npm install && cd ..         # one-time (Mode C)
bash shorts/scripts/setup.sh                # one-time Kokoro venv + models (~340 MB)

# a) you have a script
python3 studio3d/tools/make.py --name my-video --script script.txt

# b) you have a voice recording
python3 studio3d/tools/make.py --name my-video --voice recording.m4a

# c) just a thought
python3 studio3d/tools/make.py --name my-video --text "How to make viral videos with GLM-5 Flash. ..."
```

~3 minutes on 2 CPU cores for a 30 s 720p MP4 with voice, word-synced captions,
music, sound design and loudness at -14 LUFS. Output: `~/pawv1-projects/<name>/<name>.mp4`.

Flags that matter: `--look neon|sunset|midnight|candy`, `--size vertical` (shorts),
`--voice-name af_heart`, `--speed 1.1`, `--out path.mp4`, `--resume-render`.

## Quickstart (Mode D - stick-figure story video)

```bash
cd studio2d && npm install && npx playwright install chromium   # one-time
python3 tools/verify_kit.py && python3 tools/doctor.py          # must be 29/29 and all OK

python3 tools/new_project.py --name my-story --voice voice.mp3 --aspect 16:9 --resolution 1080p
python3 tools/transcribe.py --project projects/my-story --lang en --model small
python3 tools/beats.py --project projects/my-story
# write story/bible.md + scenes/ (see docs/references/), then QC and render:
node render.mjs --project projects/my-story --sheet --scale 0.5
node render.mjs --project projects/my-story && python3 audio/mix.py --project projects/my-story
```

Voice + script in, animated stick-figure film out: Whisper word timings, five switchable
colour styles, three.js 3D shots, generated music and SFX, 16:9 or 9:16 up to 4K.
Docs: `studio2d/docs/references/` (style bible, engine API, story breakdown, sound, QC).

The full manual (data contracts, scene list, troubleshooting, agent rules) is in
**SKILL.md** - read it before your first run.
